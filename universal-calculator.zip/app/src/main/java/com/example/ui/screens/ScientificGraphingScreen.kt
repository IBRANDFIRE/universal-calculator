package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CalcRepository
import com.example.engine.ScientificCalculators
import com.example.ui.components.GraphingCanvas
import com.example.ui.components.HapticFeedbackManager
import kotlinx.coroutines.launch

@Composable
fun ScientificGraphingScreen(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(initialTab) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }
    val tabTitles = listOf("Graphing", "Calculus", "Equations", "Matrix & Vector", "Statistics")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("scientific_screen")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 8.dp,
            modifier = Modifier.fillMaxWidth().testTag("scientific_tab_row")
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        haptics.tick()
                        selectedTab = index
                    },
                    text = { Text(title) },
                    modifier = Modifier.testTag("sci_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            0 -> GraphingCalculatorView(repository, haptics)
            1 -> CalculusView(repository, haptics)
            2 -> EquationSolverView(repository, haptics)
            3 -> MatrixVectorView(repository, haptics)
            4 -> StatisticsView(repository, haptics)
        }
    }
}

@Composable
fun GraphingCalculatorView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var functionExpr by remember { mutableStateOf("sin(x)") }
    var detectedRoots by remember { mutableStateOf<List<Double>>(emptyList()) }
    val coroutineScope = rememberCoroutineScope()

    val presets = listOf("sin(x)", "cos(x)", "x^2 - 4", "x^3 - 3*x", "sqrt(abs(x))", "1 / (x^2 + 1)")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = functionExpr,
            onValueChange = { functionExpr = it },
            label = { Text("Function f(x)") },
            leadingIcon = { Icon(Icons.Default.Functions, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().testTag("graph_function_input")
        )

        // Preset Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Presets:", style = MaterialTheme.typography.labelMedium, modifier = Modifier.align(Alignment.CenterVertically))
            presets.take(3).forEach { preset ->
                SuggestionChip(
                    onClick = {
                        haptics.tick()
                        functionExpr = preset
                    },
                    label = { Text(preset) }
                )
            }
        }

        // Interactive 2D Graph Canvas
        GraphingCanvas(
            expression = functionExpr,
            onRootsFound = { detectedRoots = it }
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Analysis & Roots", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (detectedRoots.isNotEmpty()) {
                    Text(
                        "Found roots at x ≈ " + detectedRoots.joinToString(", ") { String.format("%.3f", it) },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text("No real roots detected in current viewport", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Button(
            onClick = {
                haptics.heavyTick()
                coroutineScope.launch {
                    repository.saveCalculation(
                        category = "Scientific",
                        calculatorName = "Graphing 2D",
                        expression = "f(x) = $functionExpr",
                        result = "Roots: ${detectedRoots.joinToString { String.format("%.2f", it) }}"
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Graph Function")
        }
    }
}

@Composable
fun CalculusView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var functionExpr by remember { mutableStateOf("x^2 + 2*x") }
    var evalXStr by remember { mutableStateOf("2.0") }
    var lowerBoundStr by remember { mutableStateOf("0.0") }
    var upperBoundStr by remember { mutableStateOf("3.0") }

    var derivativeResult by remember { mutableStateOf<Double?>(null) }
    var integralResult by remember { mutableStateOf<Double?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = functionExpr,
            onValueChange = { functionExpr = it },
            label = { Text("Function f(x)") },
            modifier = Modifier.fillMaxWidth().testTag("calc_fn_input")
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Numerical Derivative f'(x)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = evalXStr,
                        onValueChange = { evalXStr = it },
                        label = { Text("At x₀") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            haptics.tick()
                            val x0 = evalXStr.toDoubleOrNull() ?: 0.0
                            derivativeResult = ScientificCalculators.numericalDerivative(functionExpr, x0)
                        }
                    ) {
                        Text("Calculate f'")
                    }
                }
                if (derivativeResult != null) {
                    Text(
                        "f'($evalXStr) ≈ ${String.format("%.5f", derivativeResult)}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Definite Integral ∫[a,b] f(x) dx", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = lowerBoundStr,
                        onValueChange = { lowerBoundStr = it },
                        label = { Text("Lower Bound a") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = upperBoundStr,
                        onValueChange = { upperBoundStr = it },
                        label = { Text("Upper Bound b") },
                        modifier = Modifier.weight(1f)
                    )
                }
                Button(
                    onClick = {
                        haptics.tick()
                        val a = lowerBoundStr.toDoubleOrNull() ?: 0.0
                        val b = upperBoundStr.toDoubleOrNull() ?: 1.0
                        integralResult = ScientificCalculators.definiteIntegral(functionExpr, a, b)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Calculate Integral")
                }
                if (integralResult != null) {
                    Text(
                        "∫ ≈ ${String.format("%.5f", integralResult)}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun EquationSolverView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var aStr by remember { mutableStateOf("1") }
    var bStr by remember { mutableStateOf("-5") }
    var cStr by remember { mutableStateOf("6") }
    var quadResult by remember { mutableStateOf<ScientificCalculators.QuadraticResult?>(null) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Quadratic Solver: ax² + bx + c = 0", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = aStr, onValueChange = { aStr = it }, label = { Text("a") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = bStr, onValueChange = { bStr = it }, label = { Text("b") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = cStr, onValueChange = { cStr = it }, label = { Text("c") }, modifier = Modifier.weight(1f))
                }
                Button(
                    onClick = {
                        haptics.heavyTick()
                        val a = aStr.toDoubleOrNull() ?: 1.0
                        val b = bStr.toDoubleOrNull() ?: 0.0
                        val c = cStr.toDoubleOrNull() ?: 0.0
                        quadResult = ScientificCalculators.solveQuadratic(a, b, c)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Solve Roots")
                }

                when (val res = quadResult) {
                    is ScientificCalculators.QuadraticResult.RealRoots -> {
                        Text(
                            "Real Roots: x₁ = ${String.format("%.4f", res.x1)}, x₂ = ${String.format("%.4f", res.x2)} (Δ = ${res.discriminant})",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    is ScientificCalculators.QuadraticResult.ComplexRoots -> {
                        Text(
                            "Complex Roots: ${String.format("%.4f", res.realPart)} ± ${String.format("%.4f", res.imaginaryPart)}i",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    ScientificCalculators.QuadraticResult.DegenerateLinear -> {
                        Text("Not quadratic (a = 0)", color = MaterialTheme.colorScheme.error)
                    }
                    null -> {}
                }
            }
        }
    }
}

@Composable
fun MatrixVectorView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    // 2x2 Matrix elements
    var m00 by remember { mutableStateOf("2") }
    var m01 by remember { mutableStateOf("1") }
    var m10 by remember { mutableStateOf("4") }
    var m11 by remember { mutableStateOf("3") }
    var matrixResult by remember { mutableStateOf<ScientificCalculators.MatrixResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2x2 Matrix Solver", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = m00, onValueChange = { m00 = it }, label = { Text("m[0,0]") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = m01, onValueChange = { m01 = it }, label = { Text("m[0,1]") }, modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = m10, onValueChange = { m10 = it }, label = { Text("m[1,0]") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = m11, onValueChange = { m11 = it }, label = { Text("m[1,1]") }, modifier = Modifier.weight(1f))
                }
                Button(
                    onClick = {
                        haptics.heavyTick()
                        val m = arrayOf(
                            doubleArrayOf(m00.toDoubleOrNull() ?: 0.0, m01.toDoubleOrNull() ?: 0.0),
                            doubleArrayOf(m10.toDoubleOrNull() ?: 0.0, m11.toDoubleOrNull() ?: 0.0)
                        )
                        matrixResult = ScientificCalculators.solveMatrix2x2(m)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Compute Det & Inverse")
                }

                matrixResult?.let { res ->
                    Text("Determinant det(A) = ${res.determinant}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    if (res.inverse != null) {
                        Text(
                            "Inverse A⁻¹:\n[ ${String.format("%.3f", res.inverse[0][0])}, ${String.format("%.3f", res.inverse[0][1])} ]\n[ ${String.format("%.3f", res.inverse[1][0])}, ${String.format("%.3f", res.inverse[1][1])} ]",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        Text("Matrix is singular (no inverse)", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun StatisticsView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var rawInput by remember { mutableStateOf("12, 15, 12, 18, 22, 25, 30, 12, 19") }
    var statsResult by remember { mutableStateOf<ScientificCalculators.StatsResult?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = rawInput,
            onValueChange = { rawInput = it },
            label = { Text("Comma-separated numbers") },
            modifier = Modifier.fillMaxWidth().testTag("stats_input")
        )

        Button(
            onClick = {
                haptics.heavyTick()
                val nums = rawInput.split(",", " ", ";")
                    .mapNotNull { it.trim().toDoubleOrNull() }
                statsResult = ScientificCalculators.calculateStatistics(nums)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Compute Statistics")
        }

        statsResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Summary Statistics (N = ${res.count})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Mean (Average): ${String.format("%.4f", res.mean)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                    Text("Median: ${String.format("%.4f", res.median)}")
                    Text("Mode: ${if (res.mode.isEmpty()) "None" else res.mode.joinToString()}")
                    Text("Sample Standard Deviation: ${String.format("%.4f", res.stdDev)}")
                    Text("Variance: ${String.format("%.4f", res.variance)}")
                    Text("Min: ${res.min}  |  Max: ${res.max}  |  Range: ${res.range}")
                }
            }
        }
    }
}
