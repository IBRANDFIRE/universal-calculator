package com.example.ui.models

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class CalcCategory(val title: String, val icon: ImageVector) {
    STANDARD("Standard", Icons.Default.Calculate),
    SCIENTIFIC("Scientific & Academic", Icons.Default.ShowChart),
    FINANCIAL("Financial & Business", Icons.Default.MonetizationOn),
    CONVERTERS("Converters", Icons.Default.SwapHoriz),
    HEALTH("Health & Fitness", Icons.Default.FitnessCenter),
    UTILITIES("Everyday Utilities", Icons.Default.Build)
}

data class CalculatorItem(
    val id: String,
    val title: String,
    val shortDescription: String,
    val category: CalcCategory,
    val icon: ImageVector,
    val searchKeywords: List<String>
)

object CalculatorRegistry {
    val ALL_CALCULATORS = listOf(
        // Standard
        CalculatorItem(
            id = "standard",
            title = "Basic Arithmetic",
            shortDescription = "High precision multi-line arithmetic with MC, MR, M+, M- memory",
            category = CalcCategory.STANDARD,
            icon = Icons.Default.Calculate,
            searchKeywords = listOf("basic", "standard", "arithmetic", "plus", "minus", "memory", "tape", "math")
        ),
        CalculatorItem(
            id = "percentage",
            title = "Percentage & Discount",
            shortDescription = "Discount finder, sales savings, and percentage changes",
            category = CalcCategory.STANDARD,
            icon = Icons.Default.Percent,
            searchKeywords = listOf("discount", "percentage", "percent", "sale", "save", "off")
        ),
        CalculatorItem(
            id = "tally",
            title = "Tally & Counter",
            shortDescription = "Digital clicker counter with step intervals and reset",
            category = CalcCategory.STANDARD,
            icon = Icons.Default.PlusOne,
            searchKeywords = listOf("tally", "counter", "clicker", "count", "steps", "inventory")
        ),

        // Scientific & Academic
        CalculatorItem(
            id = "scientific",
            title = "Advanced Scientific",
            shortDescription = "Trig, log, powers, roots, factorials, and constants",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.Functions,
            searchKeywords = listOf("scientific", "trigonometry", "sin", "cos", "tan", "log", "ln", "exponent", "sqrt", "radicals")
        ),
        CalculatorItem(
            id = "graphing",
            title = "2D Graphing Calculator",
            shortDescription = "Plot mathematical curves f(x) with interactive pan & root finder",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.ShowChart,
            searchKeywords = listOf("graph", "plot", "function", "curve", "cartesian", "roots", "extrema", "f(x)")
        ),
        CalculatorItem(
            id = "matrix",
            title = "Matrix & Vector",
            shortDescription = "Determinants, 2x2/3x3 inverses, transpose, dot and cross products",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.GridOn,
            searchKeywords = listOf("matrix", "vector", "determinant", "inverse", "dot product", "cross product", "transpose")
        ),
        CalculatorItem(
            id = "statistics",
            title = "Statistics Calculator",
            shortDescription = "Mean, median, mode, sample & population std dev, and variance",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.BarChart,
            searchKeywords = listOf("statistics", "mean", "median", "mode", "standard deviation", "variance", "average", "stats")
        ),
        CalculatorItem(
            id = "calculus",
            title = "Calculus (Deriv & Integral)",
            shortDescription = "Numerical derivatives f'(x) and definite integrals via Simpson's rule",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.Timeline,
            searchKeywords = listOf("calculus", "derivative", "integral", "definite integral", "tangent", "rate of change")
        ),
        CalculatorItem(
            id = "equations",
            title = "Equation Solver",
            shortDescription = "Quadratic ax²+bx+c=0 roots & 2x2 simultaneous linear systems",
            category = CalcCategory.SCIENTIFIC,
            icon = Icons.Default.Rule,
            searchKeywords = listOf("equation", "solve", "quadratic", "linear", "simultaneous", "roots", "discriminant")
        ),

        // Financial & Business
        CalculatorItem(
            id = "emi",
            title = "Mortgage & Loan EMI",
            shortDescription = "Monthly repayment schedule with full amortization table",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.Home,
            searchKeywords = listOf("emi", "loan", "mortgage", "amortization", "interest", "bank", "borrow", "principal")
        ),
        CalculatorItem(
            id = "sip",
            title = "Compound Interest & SIP",
            shortDescription = "Wealth generator for lump-sum & monthly SIP investments",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.TrendingUp,
            searchKeywords = listOf("sip", "compound", "investment", "mutual fund", "interest", "wealth", "growth")
        ),
        CalculatorItem(
            id = "currency",
            title = "Currency Converter",
            shortDescription = "Global foreign exchange rates with live conversion & offline table",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.Paid,
            searchKeywords = listOf("currency", "exchange", "usd", "eur", "gbp", "inr", "jpy", "forex", "money")
        ),
        CalculatorItem(
            id = "tip",
            title = "Tip & Bill Splitter",
            shortDescription = "Evenly divide restaurant checks with custom tip %",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.ReceiptLong,
            searchKeywords = listOf("tip", "bill", "split", "restaurant", "dining", "gratuity", "check")
        ),
        CalculatorItem(
            id = "tax",
            title = "Sales Tax, VAT & GST",
            shortDescription = "Inclusive and exclusive sales tax and value-added tax rates",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.AccountBalance,
            searchKeywords = listOf("tax", "vat", "gst", "sales tax", "gross", "net")
        ),
        CalculatorItem(
            id = "margin",
            title = "Margin & Break-Even",
            shortDescription = "Gross margin, markup %, and fixed cost break-even point",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.PieChart,
            searchKeywords = listOf("margin", "markup", "profit", "break even", "cost", "revenue", "business")
        ),
        CalculatorItem(
            id = "retirement",
            title = "Retirement Planner",
            shortDescription = "Pension corpus target and monthly savings requirement",
            category = CalcCategory.FINANCIAL,
            icon = Icons.Default.Elderly,
            searchKeywords = listOf("retirement", "pension", "corpus", "savings", "401k", "financial freedom")
        ),

        // Converters
        CalculatorItem(
            id = "units",
            title = "Unit Converter",
            shortDescription = "Length, area, mass, volume, speed, temp, power & fuel",
            category = CalcCategory.CONVERTERS,
            icon = Icons.Default.Straighten,
            searchKeywords = listOf("unit", "converter", "length", "metric", "imperial", "weight", "kg", "lbs", "fahrenheit", "celsius")
        ),
        CalculatorItem(
            id = "base",
            title = "Base & Programmer Calc",
            shortDescription = "Simultaneous Binary, Octal, Decimal, Hexadecimal conversion",
            category = CalcCategory.CONVERTERS,
            icon = Icons.Default.Terminal,
            searchKeywords = listOf("base", "binary", "hex", "octal", "decimal", "nibble", "programmer", "bitwise", "bit")
        ),

        // Health & Fitness
        CalculatorItem(
            id = "bmi",
            title = "BMI & BMR Calculator",
            shortDescription = "Body Mass Index classification and Basal Metabolic Rate",
            category = CalcCategory.HEALTH,
            icon = Icons.Default.AccessibilityNew,
            searchKeywords = listOf("bmi", "bmr", "weight", "height", "healthy", "body mass", "metabolism")
        ),
        CalculatorItem(
            id = "tdee",
            title = "TDEE & Calorie Burn",
            shortDescription = "Total Daily Energy Expenditure based on physical activity level",
            category = CalcCategory.HEALTH,
            icon = Icons.Default.LocalFireDepartment,
            searchKeywords = listOf("tdee", "calorie", "energy", "metabolic", "diet", "fitness", "activity")
        ),
        CalculatorItem(
            id = "bodyfat",
            title = "Body Fat % (US Navy)",
            shortDescription = "Circumference-based body composition and fat percentage",
            category = CalcCategory.HEALTH,
            icon = Icons.Default.MonitorWeight,
            searchKeywords = listOf("body fat", "fat percent", "navy method", "waist", "neck", "composition")
        ),
        CalculatorItem(
            id = "macros",
            title = "Macro Nutrients Split",
            shortDescription = "Daily grams of Protein, Carbohydrates, and Fats",
            category = CalcCategory.HEALTH,
            icon = Icons.Default.Restaurant,
            searchKeywords = listOf("macros", "nutrition", "carbs", "protein", "fat", "diet", "keto")
        ),
        CalculatorItem(
            id = "pregnancy",
            title = "Pregnancy & Due Date",
            shortDescription = "Naegele's estimated delivery date & gestational trimester tracker",
            category = CalcCategory.HEALTH,
            icon = Icons.Default.ChildCare,
            searchKeywords = listOf("pregnancy", "due date", "gestation", "baby", "trimester", "conception")
        ),

        // Everyday Utilities
        CalculatorItem(
            id = "date",
            title = "Date & Duration",
            shortDescription = "Calendar span between two dates and interval calculator",
            category = CalcCategory.UTILITIES,
            icon = Icons.Default.DateRange,
            searchKeywords = listOf("date", "time", "calendar", "duration", "days between", "span")
        ),
        CalculatorItem(
            id = "age",
            title = "Age & Birthday Countdown",
            shortDescription = "Exact years, months, days, hours lived and countdown to next birthday",
            category = CalcCategory.UTILITIES,
            icon = Icons.Default.Cake,
            searchKeywords = listOf("age", "birthday", "born", "years old", "countdown")
        ),
        CalculatorItem(
            id = "construction",
            title = "Construction Estimator",
            shortDescription = "Paint cans, concrete slab volume, and floor tiles estimator",
            category = CalcCategory.UTILITIES,
            icon = Icons.Default.HomeRepairService,
            searchKeywords = listOf("construction", "paint", "concrete", "tiles", "home improvement", "diy", "flooring")
        ),
        CalculatorItem(
            id = "gpa",
            title = "GPA Calculator",
            shortDescription = "Weighted collegiate Grade Point Average by credit hours",
            category = CalcCategory.UTILITIES,
            icon = Icons.Default.School,
            searchKeywords = listOf("gpa", "grade", "credits", "college", "university", "score")
        ),
        CalculatorItem(
            id = "aspect_ratio",
            title = "Aspect Ratio & Resolution",
            shortDescription = "Proportional screen dimensions, 16:9, 4:3, and custom scaling",
            category = CalcCategory.UTILITIES,
            icon = Icons.Default.AspectRatio,
            searchKeywords = listOf("aspect ratio", "resolution", "resizer", "16:9", "4:3", "pixel", "dimensions")
        )
    )

    fun getById(id: String): CalculatorItem? = ALL_CALCULATORS.find { it.id == id }

    fun search(query: String): List<CalculatorItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return ALL_CALCULATORS
        return ALL_CALCULATORS.filter { item ->
            item.title.lowercase().contains(q) ||
            item.shortDescription.lowercase().contains(q) ||
            item.category.title.lowercase().contains(q) ||
            item.searchKeywords.any { it.contains(q) }
        }
    }
}
