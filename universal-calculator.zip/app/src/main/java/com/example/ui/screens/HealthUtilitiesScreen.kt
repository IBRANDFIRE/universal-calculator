package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CalcRepository
import com.example.engine.HealthCalculators
import com.example.engine.UtilityCalculators
import com.example.ui.components.HapticFeedbackManager
import java.time.LocalDate

@Composable
fun HealthUtilitiesScreen(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(initialTab) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }
    val tabs = listOf("BMI & BMR", "TDEE & Cal", "Body Fat %", "Date & Age", "Construction", "GPA & Aspect")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("health_utilities_screen")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 8.dp,
            modifier = Modifier.fillMaxWidth().testTag("health_tab_row")
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        haptics.tick()
                        selectedTab = index
                    },
                    text = { Text(title) },
                    modifier = Modifier.testTag("health_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> BmiBmrView(haptics)
            1 -> TdeeMacrosView(haptics)
            2 -> BodyFatView(haptics)
            3 -> DateAgeView(haptics)
            4 -> ConstructionEstimatorView(haptics)
            5 -> GpaAspectView(haptics)
        }
    }
}

@Composable
fun BmiBmrView(haptics: HapticFeedbackManager) {
    var weightKgStr by remember { mutableStateOf("70") }
    var heightCmStr by remember { mutableStateOf("175") }
    var ageStr by remember { mutableStateOf("28") }
    var gender by remember { mutableStateOf(HealthCalculators.Gender.MALE) }

    val weight = weightKgStr.toDoubleOrNull() ?: 70.0
    val height = heightCmStr.toDoubleOrNull() ?: 175.0
    val age = ageStr.toIntOrNull() ?: 28

    val bmiResult = HealthCalculators.calculateBmi(weight, height)
    val bmr = HealthCalculators.calculateBmr(weight, height, age, gender)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("BMI: ${String.format("%.1f", bmiResult.bmi)}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Category: ${bmiResult.category}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Healthy Weight Range: ${String.format("%.1f", bmiResult.healthyWeightRangeMin)} - ${String.format("%.1f", bmiResult.healthyWeightRangeMax)} kg", style = MaterialTheme.typography.bodySmall)
                Text("Basal Metabolic Rate (BMR): ${bmr.toInt()} kcal/day", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = gender == HealthCalculators.Gender.MALE,
                onClick = { gender = HealthCalculators.Gender.MALE },
                label = { Text("Male") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = gender == HealthCalculators.Gender.FEMALE,
                onClick = { gender = HealthCalculators.Gender.FEMALE },
                label = { Text("Female") },
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(value = weightKgStr, onValueChange = { weightKgStr = it }, label = { Text("Weight (kg)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = heightCmStr, onValueChange = { heightCmStr = it }, label = { Text("Height (cm)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = ageStr, onValueChange = { ageStr = it }, label = { Text("Age (years)") }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun TdeeMacrosView(haptics: HapticFeedbackManager) {
    var weightKgStr by remember { mutableStateOf("75") }
    var heightCmStr by remember { mutableStateOf("178") }
    var ageStr by remember { mutableStateOf("30") }
    var activity by remember { mutableStateOf(HealthCalculators.ActivityLevel.MODERATE) }

    val w = weightKgStr.toDoubleOrNull() ?: 75.0
    val h = heightCmStr.toDoubleOrNull() ?: 178.0
    val a = ageStr.toIntOrNull() ?: 30

    val bmr = HealthCalculators.calculateBmr(w, h, a, HealthCalculators.Gender.MALE)
    val tdee = HealthCalculators.calculateTdee(bmr, activity)
    val macros = HealthCalculators.calculateMacros(tdee, 40.0, 30.0, 30.0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Daily Maintenance Calories (TDEE)", style = MaterialTheme.typography.labelMedium)
                Text("${tdee.toInt()} kcal/day", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Standard 40/30/30 Macro Breakdown:")
                Text("• Carbs: ${macros.carbsGrams.toInt()}g (${macros.carbsCalories.toInt()} kcal)")
                Text("• Protein: ${macros.proteinGrams.toInt()}g (${macros.proteinCalories.toInt()} kcal)")
                Text("• Fat: ${macros.fatGrams.toInt()}g (${macros.fatCalories.toInt()} kcal)")
            }
        }

        Text("Activity Level:", style = MaterialTheme.typography.labelMedium)
        HealthCalculators.ActivityLevel.values().forEach { act ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                RadioButton(selected = activity == act, onClick = { activity = act })
                Text(act.label, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun BodyFatView(haptics: HapticFeedbackManager) {
    var heightCmStr by remember { mutableStateOf("178") }
    var neckCmStr by remember { mutableStateOf("38") }
    var waistCmStr by remember { mutableStateOf("84") }
    var gender by remember { mutableStateOf(HealthCalculators.Gender.MALE) }

    val h = heightCmStr.toDoubleOrNull() ?: 178.0
    val n = neckCmStr.toDoubleOrNull() ?: 38.0
    val w = waistCmStr.toDoubleOrNull() ?: 84.0

    val bfResult = HealthCalculators.calculateNavyBodyFat(gender, h, n, w)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("US Navy Body Fat %", style = MaterialTheme.typography.labelMedium)
                Text(
                    if (bfResult != null) "${String.format("%.1f", bfResult.bodyFatPercent)}%" else "Incomplete data",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                bfResult?.let {
                    Text("Category: ${it.category}", style = MaterialTheme.typography.titleSmall)
                }
            }
        }

        OutlinedTextField(value = heightCmStr, onValueChange = { heightCmStr = it }, label = { Text("Height (cm)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = neckCmStr, onValueChange = { neckCmStr = it }, label = { Text("Neck Circumference (cm)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = waistCmStr, onValueChange = { waistCmStr = it }, label = { Text("Waist Circumference (cm)") }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun DateAgeView(haptics: HapticFeedbackManager) {
    var birthYearStr by remember { mutableStateOf("1996") }
    var birthMonthStr by remember { mutableStateOf("5") }
    var birthDayStr by remember { mutableStateOf("15") }

    val bYear = birthYearStr.toIntOrNull() ?: 1996
    val bMonth = (birthMonthStr.toIntOrNull() ?: 5).coerceIn(1, 12)
    val bDay = (birthDayStr.toIntOrNull() ?: 15).coerceIn(1, 31)

    val birthDate = try { LocalDate.of(bYear, bMonth, bDay) } catch (e: Exception) { LocalDate.of(1996, 5, 15) }
    val ageResult = UtilityCalculators.calculateAge(birthDate)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Exact Age", style = MaterialTheme.typography.labelMedium)
                Text(
                    "${ageResult.years} yrs, ${ageResult.months} mos, ${ageResult.days} days",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("Total days lived: ${String.format("%,d", ageResult.totalDaysLived)}")
                Text("Total hours: ${String.format("%,d", ageResult.totalHoursLived)}")
                Text("Next Birthday in: ${ageResult.daysToNextBirthday} days", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = birthYearStr, onValueChange = { birthYearStr = it }, label = { Text("Year") }, modifier = Modifier.weight(1.2f))
            OutlinedTextField(value = birthMonthStr, onValueChange = { birthMonthStr = it }, label = { Text("Month (1-12)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = birthDayStr, onValueChange = { birthDayStr = it }, label = { Text("Day") }, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun ConstructionEstimatorView(haptics: HapticFeedbackManager) {
    var lengthMStr by remember { mutableStateOf("5") }
    var heightMStr by remember { mutableStateOf("2.8") }
    var coatsStr by remember { mutableStateOf("2") }

    val len = lengthMStr.toDoubleOrNull() ?: 5.0
    val h = heightMStr.toDoubleOrNull() ?: 2.8
    val coats = coatsStr.toIntOrNull() ?: 2

    val paintResult = UtilityCalculators.calculatePaint(len, h, coats)
    val concreteResult = UtilityCalculators.calculateConcrete(len, 4.0, 0.1)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Paint Estimator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Total Wall Area: ${paintResult.totalWallArea} m²")
                Text("Paint required: ${String.format("%.1f", paintResult.litersRequired)} Liters (${paintResult.cansRequired} cans of 4L)", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Concrete Slab Estimator (10cm depth)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Net Volume: ${String.format("%.2f", concreteResult.netVolumeM3)} m³")
                Text("With 10% wastage: ${String.format("%.2f", concreteResult.volumeWithWastageM3)} m³", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Text("Estimated Premix Bags (50kg): ~${concreteResult.premixBags50kg} bags")
            }
        }

        OutlinedTextField(value = lengthMStr, onValueChange = { lengthMStr = it }, label = { Text("Wall / Slab Length (m)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = heightMStr, onValueChange = { heightMStr = it }, label = { Text("Wall Height (m)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = coatsStr, onValueChange = { coatsStr = it }, label = { Text("Number of Coats") }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun GpaAspectView(haptics: HapticFeedbackManager) {
    var origWStr by remember { mutableStateOf("1920") }
    var origHStr by remember { mutableStateOf("1080") }
    var targetWStr by remember { mutableStateOf("1280") }

    val ow = origWStr.toIntOrNull() ?: 1920
    val oh = origHStr.toIntOrNull() ?: 1080
    val tw = targetWStr.toIntOrNull() ?: 1280

    val aspect = UtilityCalculators.calculateAspectRatio(ow, oh, tw, null)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Aspect Ratio: ${aspect.ratioString}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Resized Dimensions: ${aspect.scaledWidth} x ${aspect.scaledHeight} px")
            }
        }

        OutlinedTextField(value = origWStr, onValueChange = { origWStr = it }, label = { Text("Original Width (px)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = origHStr, onValueChange = { origHStr = it }, label = { Text("Original Height (px)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = targetWStr, onValueChange = { targetWStr = it }, label = { Text("Target Width (px)") }, modifier = Modifier.fillMaxWidth())
    }
}
