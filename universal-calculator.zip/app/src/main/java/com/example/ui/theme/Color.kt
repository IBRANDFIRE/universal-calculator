package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.data.AccentPalette

// Dark Canvas Base Colors
val DarkBackground = Color(0xFF0F172A) // Slate 900
val DarkSurface = Color(0xFF1E293B)    // Slate 800
val DarkSurfaceVariant = Color(0xFF334155) // Slate 700
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkKeypadSurface = Color(0xFF1E293B)
val DarkKeypadOperator = Color(0xFF334155)

// Light Canvas Base Colors
val LightBackground = Color(0xFFF8FAFC) // Slate 50
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0) // Slate 200
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightKeypadSurface = Color(0xFFF1F5F9)
val LightKeypadOperator = Color(0xFFE2E8F0)

fun getPrimaryColor(accent: AccentPalette, isDark: Boolean): Color {
    return when (accent) {
        AccentPalette.SAPPHIRE -> if (isDark) Color(0xFF60A5FA) else Color(0xFF2563EB)
        AccentPalette.EMERALD -> if (isDark) Color(0xFF34D399) else Color(0xFF059669)
        AccentPalette.AMBER -> if (isDark) Color(0xFFFBBF24) else Color(0xFFD97706)
        AccentPalette.AMETHYST -> if (isDark) Color(0xFFA78BFA) else Color(0xFF7C3AED)
        AccentPalette.CORAL -> if (isDark) Color(0xFFFB7185) else Color(0xFFE11D48)
        AccentPalette.RUBY -> if (isDark) Color(0xFFF472B6) else Color(0xFFDB2777)
        AccentPalette.SUNSET -> if (isDark) Color(0xFFFB923C) else Color(0xFFEA580C)
        AccentPalette.TEAL -> if (isDark) Color(0xFF2DD4BF) else Color(0xFF0D9488)
        AccentPalette.CYAN -> if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)
        AccentPalette.INDIGO -> if (isDark) Color(0xFF818CF8) else Color(0xFF4F46E5)
        AccentPalette.VIOLET -> if (isDark) Color(0xFFC084FC) else Color(0xFF9333EA)
        AccentPalette.GOLD -> if (isDark) Color(0xFFFACC15) else Color(0xFFCA8A04)
        AccentPalette.MINT -> if (isDark) Color(0xFF4ADE80) else Color(0xFF16A34A)
        AccentPalette.SLATE -> if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)
    }
}

fun getSecondaryColor(accent: AccentPalette, isDark: Boolean): Color {
    return when (accent) {
        AccentPalette.SAPPHIRE -> if (isDark) Color(0xFF93C5FD) else Color(0xFF3B82F6)
        AccentPalette.EMERALD -> if (isDark) Color(0xFF6EE7B7) else Color(0xFF10B981)
        AccentPalette.AMBER -> if (isDark) Color(0xFFFCD34D) else Color(0xFFF59E0B)
        AccentPalette.AMETHYST -> if (isDark) Color(0xFFC4B5FD) else Color(0xFF8B5CF6)
        AccentPalette.CORAL -> if (isDark) Color(0xFFFDA4AF) else Color(0xFFF43F5E)
        AccentPalette.RUBY -> if (isDark) Color(0xFFFBCFE8) else Color(0xFFF472B6)
        AccentPalette.SUNSET -> if (isDark) Color(0xFFFED7AA) else Color(0xFFFB923C)
        AccentPalette.TEAL -> if (isDark) Color(0xFF99F6E4) else Color(0xFF2DD4BF)
        AccentPalette.CYAN -> if (isDark) Color(0xFFBAE6FD) else Color(0xFF38BDF8)
        AccentPalette.INDIGO -> if (isDark) Color(0xFFC7D2FE) else Color(0xFF818CF8)
        AccentPalette.VIOLET -> if (isDark) Color(0xFFE9D5FF) else Color(0xFFC084FC)
        AccentPalette.GOLD -> if (isDark) Color(0xFFFEF08A) else Color(0xFFFACC15)
        AccentPalette.MINT -> if (isDark) Color(0xFFBBF7D0) else Color(0xFF4ADE80)
        AccentPalette.SLATE -> if (isDark) Color(0xFFCBD5E1) else Color(0xFF64748B)
    }
}
