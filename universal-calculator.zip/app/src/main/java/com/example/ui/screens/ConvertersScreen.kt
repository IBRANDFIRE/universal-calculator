package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalcRepository
import com.example.engine.UnitConverters
import com.example.ui.components.HapticFeedbackManager

@Composable
fun ConvertersScreen(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(initialTab) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }
    val tabs = listOf("Unit Converter", "Base Converter (Hex/Bin/Dec)")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("converters_screen")
    ) {
        TabRow(selectedTabIndex = selectedTab, modifier = Modifier.fillMaxWidth()) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        haptics.tick()
                        selectedTab = index
                    },
                    text = { Text(title) },
                    modifier = Modifier.testTag("conv_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTab) {
            0 -> MultiUnitConverterView(haptics)
            1 -> BaseConverterView(haptics)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MultiUnitConverterView(haptics: HapticFeedbackManager) {
    var selectedCategory by remember { mutableStateOf(UnitConverters.Category.LENGTH) }
    val units = remember(selectedCategory) { UnitConverters.getUnitsForCategory(selectedCategory) }

    var fromUnitId by remember(selectedCategory) { mutableStateOf(units.first().id) }
    var toUnitId by remember(selectedCategory) { mutableStateOf(if (units.size > 1) units[1].id else units.first().id) }
    var inputValueStr by remember { mutableStateOf("1") }

    val inputValue = inputValueStr.toDoubleOrNull() ?: 0.0
    val convertedValue = UnitConverters.convert(inputValue, selectedCategory, fromUnitId, toUnitId)

    val fromUnit = units.find { it.id == fromUnitId } ?: units.first()
    val toUnit = units.find { it.id == toUnitId } ?: units.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Category Chips
        ScrollableTabRow(
            selectedTabIndex = UnitConverters.Category.values().indexOf(selectedCategory),
            edgePadding = 0.dp
        ) {
            UnitConverters.Category.values().forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = {
                        haptics.tick()
                        selectedCategory = cat
                    },
                    text = { Text(cat.displayName, fontSize = 12.sp) }
                )
            }
        }

        // Result Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "$inputValue ${fromUnit.symbol} =",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "${formatConverted(convertedValue)} ${toUnit.symbol}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "${toUnit.name}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        OutlinedTextField(
            value = inputValueStr,
            onValueChange = { inputValueStr = it },
            label = { Text("Value to convert") },
            modifier = Modifier.fillMaxWidth().testTag("unit_input_val")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            UnitSelectDropdown(
                label = "From",
                units = units,
                selectedId = fromUnitId,
                modifier = Modifier.weight(1f),
                onSelect = { fromUnitId = it }
            )

            IconButton(
                onClick = {
                    haptics.tick()
                    val temp = fromUnitId
                    fromUnitId = toUnitId
                    toUnitId = temp
                }
            ) {
                Icon(Icons.Default.SwapHoriz, contentDescription = "Swap")
            }

            UnitSelectDropdown(
                label = "To",
                units = units,
                selectedId = toUnitId,
                modifier = Modifier.weight(1f),
                onSelect = { toUnitId = it }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitSelectDropdown(
    label: String,
    units: List<UnitConverters.UnitItem>,
    selectedId: String,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val current = units.find { it.id == selectedId } ?: units.first()

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = "${current.name} (${current.symbol})",
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            units.forEach { u ->
                DropdownMenuItem(
                    text = { Text("${u.name} (${u.symbol})") },
                    onClick = {
                        onSelect(u.id)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun BaseConverterView(haptics: HapticFeedbackManager) {
    var inputMode by remember { mutableStateOf(10) } // 10 = Decimal, 16 = Hex, 2 = Bin, 8 = Oct
    var rawInput by remember { mutableStateOf("255") }
    val clipboard: ClipboardManager = LocalClipboardManager.current

    val result = remember(rawInput, inputMode) {
        UnitConverters.convertBase(rawInput, inputMode)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Input Radix (Base):", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(10 to "DEC (10)", 16 to "HEX (16)", 2 to "BIN (2)", 8 to "OCT (8)").forEach { (base, title) ->
                FilterChip(
                    selected = inputMode == base,
                    onClick = {
                        haptics.tick()
                        inputMode = base
                        rawInput = when (base) {
                            10 -> result?.decimal ?: "0"
                            16 -> result?.hexadecimal ?: "0"
                            2 -> result?.binary?.replace(" ", "") ?: "0"
                            8 -> result?.octal ?: "0"
                            else -> "0"
                        }
                    },
                    label = { Text(title) }
                )
            }
        }

        OutlinedTextField(
            value = rawInput,
            onValueChange = { rawInput = it },
            label = { Text("Value in Base $inputMode") },
            modifier = Modifier.fillMaxWidth().testTag("base_input_val")
        )

        Spacer(modifier = Modifier.height(4.dp))

        result?.let { res ->
            BaseCard("HEXADECIMAL", "0x${res.hexadecimal}", clipboard)
            BaseCard("DECIMAL", res.decimal, clipboard)
            BaseCard("OCTAL", "0o${res.octal}", clipboard)
            BaseCard("BINARY", res.binary, clipboard)

            Text(
                "Bit length: ${res.bitCount} bits",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun BaseCard(title: String, value: String, clipboard: ClipboardManager) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { clipboard.setText(AnnotatedString(value)) },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
        }
    }
}

private fun formatConverted(d: Double): String {
    return if (kotlin.math.abs(d) >= 1e6 || (kotlin.math.abs(d) < 1e-4 && d != 0.0)) {
        String.format("%.4e", d)
    } else {
        String.format("%.4f", d).trimEnd('0').trimEnd('.')
    }
}
