package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.ScientificCalculators
import kotlin.math.roundToInt

@Composable
fun GraphingCanvas(
    expression: String,
    modifier: Modifier = Modifier,
    curveColor: Color = MaterialTheme.colorScheme.primary,
    onRootsFound: (List<Double>) -> Unit = {}
) {
    var xMin by remember { mutableStateOf(-10.0) }
    var xMax by remember { mutableStateOf(10.0) }
    var yMin by remember { mutableStateOf(-10.0) }
    var yMax by remember { mutableStateOf(10.0) }

    val roots = remember(expression, xMin, xMax) {
        try {
            ScientificCalculators.findRoots(expression, xMin, xMax)
        } catch (e: Exception) {
            emptyList()
        }
    }

    LaunchedEffect(roots) {
        onRootsFound(roots)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("graph_canvas")
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val xRange = xMax - xMin
                        val yRange = yMax - yMin

                        // Pan
                        val dx = -(pan.x / size.width) * xRange
                        val dy = (pan.y / size.height) * yRange
                        xMin += dx
                        xMax += dx
                        yMin += dy
                        yMax += dy

                        // Zoom
                        if (zoom != 1f && zoom > 0f) {
                            val newXRange = xRange / zoom
                            val newYRange = yRange / zoom
                            val xCenter = (xMin + xMax) / 2.0
                            val yCenter = (yMin + yMax) / 2.0
                            xMin = xCenter - newXRange / 2.0
                            xMax = xCenter + newXRange / 2.0
                            yMin = yCenter - newYRange / 2.0
                            yMax = yCenter + newYRange / 2.0
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            fun toScreenX(x: Double): Float = ((x - xMin) / (xMax - xMin) * width).toFloat()
            fun toScreenY(y: Double): Float = (height - (y - yMin) / (yMax - yMin) * height).toFloat()

            // Draw grid lines
            val gridColor = Color.White.copy(alpha = 0.12f)
            val axisColor = Color.White.copy(alpha = 0.6f)

            val xStep = calculateGridStep(xMax - xMin)
            var curX = (xMin / xStep).toInt() * xStep
            while (curX <= xMax) {
                val sx = toScreenX(curX)
                drawLine(gridColor, Offset(sx, 0f), Offset(sx, height), strokeWidth = 1f)
                curX += xStep
            }

            val yStep = calculateGridStep(yMax - yMin)
            var curY = (yMin / yStep).toInt() * yStep
            while (curY <= yMax) {
                val sy = toScreenY(curY)
                drawLine(gridColor, Offset(0f, sy), Offset(width, sy), strokeWidth = 1f)
                curY += yStep
            }

            // Draw X and Y Axes
            val xAxisY = toScreenY(0.0)
            if (xAxisY in 0f..height) {
                drawLine(axisColor, Offset(0f, xAxisY), Offset(width, xAxisY), strokeWidth = 2f)
            }
            val yAxisX = toScreenX(0.0)
            if (yAxisX in 0f..width) {
                drawLine(axisColor, Offset(yAxisX, 0f), Offset(yAxisX, height), strokeWidth = 2f)
            }

            // Draw function curve
            try {
                val sampledPoints = ScientificCalculators.sampleFunction(expression, xMin, xMax, steps = 180)
                if (sampledPoints.size > 1) {
                    val path = Path()
                    var first = true

                    for (pt in sampledPoints) {
                        val sx = toScreenX(pt.x)
                        val sy = toScreenY(pt.y)

                        if (sy.isFinite() && sy in -1000f..(height + 1000f)) {
                            if (first) {
                                path.moveTo(sx, sy)
                                first = false
                            } else {
                                path.lineTo(sx, sy)
                            }
                        } else {
                            first = true
                        }
                    }
                    drawPath(path, color = curveColor, style = Stroke(width = 3.5f))
                }

                // Draw roots
                for (root in roots) {
                    val rx = toScreenX(root)
                    val ry = toScreenY(0.0)
                    if (rx in 0f..width && ry in 0f..height) {
                        drawCircle(Color(0xFFEF4444), radius = 6f, center = Offset(rx, ry))
                        drawCircle(Color.White, radius = 2.5f, center = Offset(rx, ry))
                    }
                }
            } catch (e: Exception) {
                // Skip on invalid math syntax
            }
        }

        // Overlay control buttons
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            FilledTonalIconButton(
                onClick = {
                    val xCenter = (xMin + xMax) / 2.0
                    val yCenter = (yMin + yMax) / 2.0
                    val xSpan = (xMax - xMin) * 0.75
                    val ySpan = (yMax - yMin) * 0.75
                    xMin = xCenter - xSpan / 2.0
                    xMax = xCenter + xSpan / 2.0
                    yMin = yCenter - ySpan / 2.0
                    yMax = yCenter + ySpan / 2.0
                },
                modifier = Modifier.size(36.dp).testTag("zoom_in_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In", modifier = Modifier.size(18.dp))
            }
            FilledTonalIconButton(
                onClick = {
                    val xCenter = (xMin + xMax) / 2.0
                    val yCenter = (yMin + yMax) / 2.0
                    val xSpan = (xMax - xMin) * 1.33
                    val ySpan = (yMax - yMin) * 1.33
                    xMin = xCenter - xSpan / 2.0
                    xMax = xCenter + xSpan / 2.0
                    yMin = yCenter - ySpan / 2.0
                    yMax = yCenter + ySpan / 2.0
                },
                modifier = Modifier.size(36.dp).testTag("zoom_out_button")
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out", modifier = Modifier.size(18.dp))
            }
            FilledTonalIconButton(
                onClick = {
                    xMin = -10.0
                    xMax = 10.0
                    yMin = -10.0
                    yMax = 10.0
                },
                modifier = Modifier.size(36.dp).testTag("reset_graph_button")
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = "Reset View", modifier = Modifier.size(18.dp))
            }
        }

        // Display bounds label
        Text(
            text = "X: [${xMin.roundToInt()}, ${xMax.roundToInt()}]  Y: [${yMin.roundToInt()}, ${yMax.roundToInt()}]",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp)
        )
    }
}

private fun calculateGridStep(range: Double): Double {
    return when {
        range <= 5 -> 1.0
        range <= 20 -> 2.0
        range <= 50 -> 5.0
        range <= 100 -> 10.0
        else -> 20.0
    }
}
