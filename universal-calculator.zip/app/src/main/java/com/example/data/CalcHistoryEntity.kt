package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calculation_history")
data class CalcHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // "Standard", "Financial", "Scientific", "Converter", "Health", "Utility"
    val calculatorName: String,
    val expression: String,
    val result: String,
    val details: String = "", // JSON or detailed notes (e.g. "EMI: $450/mo, Principal: $100k")
    val label: String = "", // User customized tag
    val isPinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
