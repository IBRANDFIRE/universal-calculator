package com.example.engine

import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit

object UtilityCalculators {

    data class DateDifferenceResult(
        val totalDays: Long,
        val totalWeeks: Long,
        val years: Int,
        val months: Int,
        val days: Int
    )

    fun calculateDateDiff(startDate: LocalDate, endDate: LocalDate): DateDifferenceResult {
        val start = if (startDate.isBefore(endDate)) startDate else endDate
        val end = if (startDate.isBefore(endDate)) endDate else startDate

        val period = Period.between(start, end)
        val totalDays = ChronoUnit.DAYS.between(start, end)
        val totalWeeks = totalDays / 7

        return DateDifferenceResult(
            totalDays = totalDays,
            totalWeeks = totalWeeks,
            years = period.years,
            months = period.months,
            days = period.days
        )
    }

    data class AgeResult(
        val years: Int,
        val months: Int,
        val days: Int,
        val totalDaysLived: Long,
        val totalHoursLived: Long,
        val daysToNextBirthday: Long
    )

    fun calculateAge(birthDate: LocalDate): AgeResult {
        val today = LocalDate.now()
        val period = Period.between(birthDate, today)
        val totalDays = ChronoUnit.DAYS.between(birthDate, today)
        val totalHours = totalDays * 24

        var nextBday = birthDate.withYear(today.year)
        if (nextBday.isBefore(today) || nextBday.isEqual(today)) {
            nextBday = nextBday.plusYears(1)
        }
        val daysToNextBday = ChronoUnit.DAYS.between(today, nextBday)

        return AgeResult(
            years = period.years,
            months = period.months,
            days = period.days,
            totalDaysLived = totalDays,
            totalHoursLived = totalHours,
            daysToNextBirthday = daysToNextBday
        )
    }

    data class PaintResult(
        val totalWallArea: Double,
        val netPaintableArea: Double,
        val litersRequired: Double,
        val cansRequired: Int // assuming 5-liter cans or 1-gallon
    )

    fun calculatePaint(
        lengthMeters: Double,
        heightMeters: Double,
        coats: Int,
        doorsWindowsAreaMeters: Double = 0.0,
        coveragePerLiter: Double = 10.0 // sq meters per liter
    ): PaintResult {
        val wallArea = lengthMeters * heightMeters
        val netArea = (wallArea - doorsWindowsAreaMeters).coerceAtLeast(0.0)
        val totalCoatsArea = netArea * coats
        val liters = totalCoatsArea / coveragePerLiter
        val cans = kotlin.math.ceil(liters / 4.0).toInt().coerceAtLeast(1)
        return PaintResult(wallArea, netArea, liters, cans)
    }

    data class ConcreteResult(
        val netVolumeM3: Double,
        val volumeWithWastageM3: Double,
        val premixBags50kg: Int
    )

    fun calculateConcrete(
        lengthMeters: Double,
        widthMeters: Double,
        thicknessMeters: Double,
        wastagePercent: Double = 10.0
    ): ConcreteResult {
        val netVol = lengthMeters * widthMeters * thicknessMeters
        val withWastage = netVol * (1.0 + wastagePercent / 100.0)
        // 1 cubic meter of concrete requires approx 45-50 bags of 50kg premix
        val bags = kotlin.math.ceil(withWastage * 45.0).toInt()
        return ConcreteResult(netVol, withWastage, bags)
    }

    data class TileResult(
        val totalTilesNeeded: Int,
        val boxesNeeded: Int,
        val totalAreaM2: Double
    )

    fun calculateTiles(
        roomLengthM: Double,
        roomWidthM: Double,
        tileLengthCm: Double,
        tileWidthCm: Double,
        wastagePercent: Double = 10.0,
        tilesPerBox: Int = 10
    ): TileResult {
        val roomArea = roomLengthM * roomWidthM
        val tileAreaM2 = (tileLengthCm / 100.0) * (tileWidthCm / 100.0)
        if (tileAreaM2 <= 0) return TileResult(0, 0, 0.0)

        val rawTiles = roomArea / tileAreaM2
        val tilesWithWastage = kotlin.math.ceil(rawTiles * (1.0 + wastagePercent / 100.0)).toInt()
        val boxes = kotlin.math.ceil(tilesWithWastage.toDouble() / tilesPerBox).toInt()
        return TileResult(tilesWithWastage, boxes, roomArea)
    }

    data class CourseGrade(val id: Long, val name: String, val creditHours: Double, val gradePoints: Double)

    fun calculateGpa(courses: List<CourseGrade>): Double {
        val totalCredits = courses.sumOf { it.creditHours }
        if (totalCredits <= 0) return 0.0
        val totalPoints = courses.sumOf { it.creditHours * it.gradePoints }
        return totalPoints / totalCredits
    }

    data class AspectRatioResult(
        val scaledWidth: Int,
        val scaledHeight: Int,
        val ratioString: String
    )

    fun calculateAspectRatio(originalWidth: Int, originalHeight: Int, targetWidth: Int?, targetHeight: Int?): AspectRatioResult {
        if (originalWidth <= 0 || originalHeight <= 0) return AspectRatioResult(0, 0, "1:1")

        // GCD for ratio
        var a = originalWidth
        var b = originalHeight
        while (b != 0) {
            val temp = b
            b = a % b
            a = temp
        }
        val gcd = if (a == 0) 1 else a
        val ratioStr = "${originalWidth / gcd}:${originalHeight / gcd}"

        val (newW, newH) = when {
            targetWidth != null && targetWidth > 0 -> {
                val h = (targetWidth.toDouble() * originalHeight / originalWidth).toInt()
                targetWidth to h
            }
            targetHeight != null && targetHeight > 0 -> {
                val w = (targetHeight.toDouble() * originalWidth / originalHeight).toInt()
                w to targetHeight
            }
            else -> originalWidth to originalHeight
        }

        return AspectRatioResult(newW, newH, ratioStr)
    }
}
