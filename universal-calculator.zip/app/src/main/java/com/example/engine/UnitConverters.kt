package com.example.engine

import kotlin.math.roundToLong

object UnitConverters {

    enum class Category(val displayName: String) {
        LENGTH("Length"),
        MASS("Mass & Weight"),
        AREA("Area"),
        VOLUME("Volume"),
        SPEED("Speed"),
        TEMPERATURE("Temperature"),
        DATA("Data Storage"),
        POWER("Power & Energy"),
        FUEL("Fuel Efficiency")
    }

    data class UnitItem(val id: String, val name: String, val symbol: String, val toBaseMultiplier: Double = 1.0)

    val LENGTH_UNITS = listOf(
        UnitItem("m", "Meters", "m", 1.0),
        UnitItem("km", "Kilometers", "km", 1000.0),
        UnitItem("cm", "Centimeters", "cm", 0.01),
        UnitItem("mm", "Millimeters", "mm", 0.001),
        UnitItem("mi", "Miles", "mi", 1609.344),
        UnitItem("yd", "Yards", "yd", 0.9144),
        UnitItem("ft", "Feet", "ft", 0.3048),
        UnitItem("in", "Inches", "in", 0.0254),
        UnitItem("nmi", "Nautical Miles", "NM", 1852.0)
    )

    val MASS_UNITS = listOf(
        UnitItem("kg", "Kilograms", "kg", 1.0),
        UnitItem("g", "Grams", "g", 0.001),
        UnitItem("mg", "Milligrams", "mg", 0.000001),
        UnitItem("lb", "Pounds", "lb", 0.45359237),
        UnitItem("oz", "Ounces", "oz", 0.0283495231),
        UnitItem("t", "Metric Tonnes", "t", 1000.0),
        UnitItem("st", "Stones", "st", 6.35029)
    )

    val AREA_UNITS = listOf(
        UnitItem("m2", "Square Meters", "m²", 1.0),
        UnitItem("km2", "Square Kilometers", "km²", 1_000_000.0),
        UnitItem("ft2", "Square Feet", "ft²", 0.092903),
        UnitItem("yd2", "Square Yards", "yd²", 0.836127),
        UnitItem("ac", "Acres", "ac", 4046.86),
        UnitItem("ha", "Hectares", "ha", 10000.0)
    )

    val VOLUME_UNITS = listOf(
        UnitItem("l", "Liters", "L", 1.0),
        UnitItem("ml", "Milliliters", "mL", 0.001),
        UnitItem("gal", "Gallons (US)", "gal", 3.78541),
        UnitItem("qt", "Quarts", "qt", 0.946353),
        UnitItem("pt", "Pints", "pt", 0.473176),
        UnitItem("cup", "Cups", "cup", 0.236588),
        UnitItem("floz", "Fluid Ounces", "fl oz", 0.0295735),
        UnitItem("m3", "Cubic Meters", "m³", 1000.0)
    )

    val SPEED_UNITS = listOf(
        UnitItem("mps", "Meters per second", "m/s", 1.0),
        UnitItem("kmh", "Kilometers per hour", "km/h", 0.277778),
        UnitItem("mph", "Miles per hour", "mph", 0.44704),
        UnitItem("knot", "Knots", "kn", 0.514444),
        UnitItem("fps", "Feet per second", "ft/s", 0.3048)
    )

    val DATA_UNITS = listOf(
        UnitItem("b", "Bytes", "B", 1.0),
        UnitItem("kb", "Kilobytes", "KB", 1024.0),
        UnitItem("mb", "Megabytes", "MB", 1024.0 * 1024.0),
        UnitItem("gb", "Gigabytes", "GB", 1024.0 * 1024.0 * 1024.0),
        UnitItem("tb", "Terabytes", "TB", 1024.0 * 1024.0 * 1024.0 * 1024.0),
        UnitItem("pb", "Petabytes", "PB", 1024.0 * 1024.0 * 1024.0 * 1024.0 * 1024.0),
        UnitItem("bit", "Bits", "bit", 0.125),
        UnitItem("mbps", "Megabits per sec", "Mbps", 131072.0)
    )

    val POWER_UNITS = listOf(
        UnitItem("w", "Watts", "W", 1.0),
        UnitItem("kw", "Kilowatts", "kW", 1000.0),
        UnitItem("hp", "Horsepower", "hp", 745.7),
        UnitItem("j", "Joules", "J", 1.0),
        UnitItem("kj", "Kilojoules", "kJ", 1000.0),
        UnitItem("kwh", "Kilowatt Hours", "kWh", 3_600_000.0),
        UnitItem("cal", "Calories", "cal", 4.184),
        UnitItem("kcal", "Kilocalories", "kcal", 4184.0)
    )

    fun getUnitsForCategory(category: Category): List<UnitItem> {
        return when (category) {
            Category.LENGTH -> LENGTH_UNITS
            Category.MASS -> MASS_UNITS
            Category.AREA -> AREA_UNITS
            Category.VOLUME -> VOLUME_UNITS
            Category.SPEED -> SPEED_UNITS
            Category.TEMPERATURE -> listOf(
                UnitItem("c", "Celsius", "°C"),
                UnitItem("f", "Fahrenheit", "°F"),
                UnitItem("k", "Kelvin", "K")
            )
            Category.DATA -> DATA_UNITS
            Category.POWER -> POWER_UNITS
            Category.FUEL -> listOf(
                UnitItem("mpg_us", "Miles per Gallon (US)", "MPG"),
                UnitItem("l100km", "Liters per 100km", "L/100km"),
                UnitItem("kml", "Kilometers per Liter", "km/L")
            )
        }
    }

    fun convert(value: Double, category: Category, fromUnitId: String, toUnitId: String): Double {
        if (fromUnitId == toUnitId) return value

        if (category == Category.TEMPERATURE) {
            val celsius = when (fromUnitId) {
                "c" -> value
                "f" -> (value - 32.0) * (5.0 / 9.0)
                "k" -> value - 273.15
                else -> value
            }
            return when (toUnitId) {
                "c" -> celsius
                "f" -> (celsius * (9.0 / 5.0)) + 32.0
                "k" -> celsius + 273.15
                else -> celsius
            }
        }

        if (category == Category.FUEL) {
            // Convert to km/L first
            val kml = when (fromUnitId) {
                "kml" -> value
                "mpg_us" -> value * 0.425144
                "l100km" -> if (value > 0) 100.0 / value else 0.0
                else -> value
            }
            return when (toUnitId) {
                "kml" -> kml
                "mpg_us" -> kml / 0.425144
                "l100km" -> if (kml > 0) 100.0 / kml else 0.0
                else -> kml
            }
        }

        val units = getUnitsForCategory(category)
        val fromMultiplier = units.find { it.id == fromUnitId }?.toBaseMultiplier ?: 1.0
        val toMultiplier = units.find { it.id == toUnitId }?.toBaseMultiplier ?: 1.0

        val baseValue = value * fromMultiplier
        return baseValue / toMultiplier
    }

    data class BaseConversionResult(
        val decimal: String,
        val binary: String,
        val octal: String,
        val hexadecimal: String,
        val bitCount: Int
    )

    fun convertBase(input: String, fromBase: Int): BaseConversionResult? {
        val cleanInput = input.trim()
        if (cleanInput.isEmpty()) return null

        val decimalLong = try {
            java.lang.Long.parseUnsignedLong(cleanInput, fromBase)
        } catch (e: Exception) {
            return null
        }

        val binStr = java.lang.Long.toBinaryString(decimalLong)
        val octStr = java.lang.Long.toOctalString(decimalLong)
        val decStr = java.lang.Long.toUnsignedString(decimalLong)
        val hexStr = java.lang.Long.toHexString(decimalLong).uppercase()

        return BaseConversionResult(
            decimal = decStr,
            binary = formatBinaryInNibbles(binStr),
            octal = octStr,
            hexadecimal = hexStr,
            bitCount = binStr.length
        )
    }

    private fun formatBinaryInNibbles(bin: String): String {
        val padded = if (bin.length % 4 != 0) "0".repeat(4 - (bin.length % 4)) + bin else bin
        return padded.chunked(4).joinToString(" ")
    }
}
