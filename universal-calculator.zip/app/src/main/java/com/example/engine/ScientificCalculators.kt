package com.example.engine

import kotlin.math.*

object ScientificCalculators {

    // Evaluate f(x) replacing x with value
    fun evaluateFunction(expr: String, xValue: Double): Double {
        // Insert * between number/parenthesis and variable x (e.g. 2x -> 2*x, )x -> )*x)
        val withImplicitMul = expr.replace(Regex("(?i)(?<=[0-9\\)])(?=[xX])"), "*")
            .replace(Regex("(?i)(?<=[xX])(?=[0-9\\(])"), "*")
        // Replace standalone x/X without corrupting words like exp, max, etc.
        val replaced = withImplicitMul.replace(Regex("(?i)\\bx\\b"), "($xValue)")
        val res = HighPrecisionEvaluator.evaluate(replaced, HighPrecisionEvaluator.AngleUnit.RADIANS)
        return if (res.success) res.value else Double.NaN
    }

    data class Point2D(val x: Double, val y: Double)

    fun sampleFunction(expr: String, xMin: Double, xMax: Double, steps: Int = 120): List<Point2D> {
        val points = mutableListOf<Point2D>()
        val step = (xMax - xMin) / steps
        var curX = xMin
        for (i in 0..steps) {
            val y = evaluateFunction(expr, curX)
            if (!y.isNaN() && !y.isInfinite() && abs(y) < 1000.0) {
                points.add(Point2D(curX, y))
            }
            curX += step
        }
        return points
    }

    fun findRoots(expr: String, xMin: Double, xMax: Double): List<Double> {
        val roots = mutableListOf<Double>()
        val samples = 100
        val step = (xMax - xMin) / samples
        var prevX = xMin
        var prevY = evaluateFunction(expr, prevX)

        for (i in 1..samples) {
            val curX = xMin + i * step
            val curY = evaluateFunction(expr, curX)

            if (!prevY.isNaN() && !curY.isNaN()) {
                if (prevY * curY <= 0.0) {
                    // Bisection refinement
                    var a = prevX
                    var b = curX
                    for (k in 0..15) {
                        val mid = (a + b) / 2.0
                        val midY = evaluateFunction(expr, mid)
                        if (evaluateFunction(expr, a) * midY <= 0.0) {
                            b = mid
                        } else {
                            a = mid
                        }
                    }
                    val root = (a + b) / 2.0
                    if (roots.none { abs(it - root) < 0.01 }) {
                        roots.add(root)
                    }
                }
            }
            prevX = curX
            prevY = curY
        }
        return roots
    }

    // Calculus: Numerical Derivative
    fun numericalDerivative(expr: String, x0: Double, h: Double = 1e-5): Double {
        val yPlus = evaluateFunction(expr, x0 + h)
        val yMinus = evaluateFunction(expr, x0 - h)
        return (yPlus - yMinus) / (2.0 * h)
    }

    // Calculus: Definite Integral via Simpson's 1/3 Rule
    fun definiteIntegral(expr: String, a: Double, b: Double, nIntervals: Int = 100): Double {
        val n = if (nIntervals % 2 != 0) nIntervals + 1 else nIntervals
        val h = (b - a) / n
        var sum = evaluateFunction(expr, a) + evaluateFunction(expr, b)

        for (i in 1 until n) {
            val x = a + i * h
            val y = evaluateFunction(expr, x)
            sum += if (i % 2 == 0) 2.0 * y else 4.0 * y
        }
        return (h / 3.0) * sum
    }

    // Matrix 2x2 and 3x3
    data class MatrixResult(
        val determinant: Double,
        val inverse: Array<DoubleArray>? = null,
        val transpose: Array<DoubleArray>
    )

    fun solveMatrix2x2(m: Array<DoubleArray>): MatrixResult {
        val det = m[0][0] * m[1][1] - m[0][1] * m[1][0]
        val trans = arrayOf(
            doubleArrayOf(m[0][0], m[1][0]),
            doubleArrayOf(m[0][1], m[1][1])
        )
        val inv = if (abs(det) > 1e-12) {
            arrayOf(
                doubleArrayOf(m[1][1] / det, -m[0][1] / det),
                doubleArrayOf(-m[1][0] / det, m[0][0] / det)
            )
        } else null
        return MatrixResult(det, inv, trans)
    }

    fun solveMatrix3x3(m: Array<DoubleArray>): MatrixResult {
        val det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
                  m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
                  m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])

        val trans = arrayOf(
            doubleArrayOf(m[0][0], m[1][0], m[2][0]),
            doubleArrayOf(m[0][1], m[1][1], m[2][1]),
            doubleArrayOf(m[0][2], m[1][2], m[2][2])
        )

        val inv = if (abs(det) > 1e-12) {
            val invDet = 1.0 / det
            arrayOf(
                doubleArrayOf(
                    (m[1][1] * m[2][2] - m[1][2] * m[2][1]) * invDet,
                    (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * invDet,
                    (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * invDet
                ),
                doubleArrayOf(
                    (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * invDet,
                    (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * invDet,
                    (m[0][2] * m[1][0] - m[0][0] * m[1][2]) * invDet
                ),
                doubleArrayOf(
                    (m[1][0] * m[2][1] - m[1][1] * m[2][0]) * invDet,
                    (m[0][1] * m[2][0] - m[0][0] * m[2][1]) * invDet,
                    (m[0][0] * m[1][1] - m[0][1] * m[1][0]) * invDet
                )
            )
        } else null

        return MatrixResult(det, inv, trans)
    }

    // Vectors
    fun vectorDot(v1: DoubleArray, v2: DoubleArray): Double {
        var dot = 0.0
        val size = min(v1.size, v2.size)
        for (i in 0 until size) dot += v1[i] * v2[i]
        return dot
    }

    fun vectorCross3D(v1: DoubleArray, v2: DoubleArray): DoubleArray {
        return doubleArrayOf(
            v1[1] * v2[2] - v1[2] * v2[1],
            v1[2] * v2[0] - v1[0] * v2[2],
            v1[0] * v2[1] - v1[1] * v2[0]
        )
    }

    fun vectorMagnitude(v: DoubleArray): Double {
        var sum = 0.0
        for (x in v) sum += x * x
        return sqrt(sum)
    }

    // Statistics
    data class StatsResult(
        val count: Int,
        val sum: Double,
        val mean: Double,
        val median: Double,
        val mode: List<Double>,
        val variance: Double,
        val stdDev: Double,
        val min: Double,
        val max: Double,
        val range: Double
    )

    fun calculateStatistics(numbers: List<Double>): StatsResult? {
        if (numbers.isEmpty()) return null
        val sorted = numbers.sorted()
        val n = sorted.size
        val sum = sorted.sum()
        val mean = sum / n

        val median = if (n % 2 == 1) {
            sorted[n / 2]
        } else {
            (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
        }

        val freqMap = mutableMapOf<Double, Int>()
        for (num in sorted) freqMap[num] = (freqMap[num] ?: 0) + 1
        val maxFreq = freqMap.values.maxOrNull() ?: 1
        val mode = if (maxFreq > 1) freqMap.filter { it.value == maxFreq }.keys.toList() else emptyList()

        val variance = if (n > 1) {
            sorted.sumOf { (it - mean).pow(2.0) } / (n - 1)
        } else 0.0
        val stdDev = sqrt(variance)

        val min = sorted.first()
        val max = sorted.last()
        val range = max - min

        return StatsResult(n, sum, mean, median, mode, variance, stdDev, min, max, range)
    }

    // Quadratic Equation Solver: ax^2 + bx + c = 0
    sealed class QuadraticResult {
        data class RealRoots(val x1: Double, val x2: Double, val discriminant: Double) : QuadraticResult()
        data class ComplexRoots(val realPart: Double, val imaginaryPart: Double, val discriminant: Double) : QuadraticResult()
        object DegenerateLinear : QuadraticResult()
    }

    fun solveQuadratic(a: Double, b: Double, c: Double): QuadraticResult {
        if (abs(a) < 1e-12) return QuadraticResult.DegenerateLinear
        val disc = b * b - 4.0 * a * c
        return if (disc >= 0) {
            val sqrtD = sqrt(disc)
            val x1 = (-b + sqrtD) / (2.0 * a)
            val x2 = (-b - sqrtD) / (2.0 * a)
            QuadraticResult.RealRoots(x1, x2, disc)
        } else {
            val real = -b / (2.0 * a)
            val imag = sqrt(-disc) / (2.0 * a)
            QuadraticResult.ComplexRoots(real, abs(imag), disc)
        }
    }

    // 2x2 Linear System: a1*x + b1*y = c1; a2*x + b2*y = c2
    data class LinearSystemResult(val x: Double, val y: Double, val hasUniqueSolution: Boolean)

    fun solveLinear2x2(a1: Double, b1: Double, c1: Double, a2: Double, b2: Double, c2: Double): LinearSystemResult {
        val d = a1 * b2 - a2 * b1
        if (abs(d) < 1e-12) {
            return LinearSystemResult(0.0, 0.0, false)
        }
        val dx = c1 * b2 - c2 * b1
        val dy = a1 * c2 - a2 * c1
        return LinearSystemResult(dx / d, dy / d, true)
    }
}
